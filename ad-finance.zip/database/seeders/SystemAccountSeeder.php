<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class SystemAccountSeeder extends Seeder
{
    public function run()
    {
        // 1) Make or fetch a dedicated “system” user
        $systemUser = User::firstOrCreate(
            ['email' => 'system@bank.local'],
            [
                'name'          => 'System User',
                'password' => bcrypt(Str::random(16)),
            ]
        );

        // 2) Insert the system account with id = 0
        DB::table('accounts')->updateOrInsert(
            ['id' => 1],
            [
                'user_id'        => $systemUser->id,
                'account_number' => '0000000',
                'account_name'   => 'System Account',
                'balance'        => 0.00,
                'created_at'     => now(),
                'updated_at'     => now(),
            ]
        );
    }
}
