<?php

namespace App\Enums;

enum EntryType: string
{

    case DEBIT  = 'DEBIT';
    case CREDIT = 'CREDIT';
}
